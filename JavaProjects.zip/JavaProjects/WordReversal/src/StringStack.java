// Robin Johnson
// PA 10

import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Stream;
import com.deitel.datastructures.Stack;

// Class that uses a stack to reverse the words in a sentence
public class StringStack
{
    // Main function that takes a sentence from the user and
    // prints the reversed sentence
    public static void main(String[] args)
    {
            // Ask the user for a sentence
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please enter a string");
            String sentence = scanner.nextLine();

            // Break the sentence into individual words
            // so that they can be reversed
            String[] wordsArray = sentence.split(" ");

            // Add the words to a stack using a stream
            Stack<String> reversedWords = new Stack<>();
            Stream<String> wordsStream = Arrays.stream(wordsArray);
            wordsStream.forEach(reversedWords::push);

            // Print the stack by popping the elements,
            // so their order will be reversed
            System.out.println("Input string in reversed order");
            while (!reversedWords.isEmpty())
            {
                String poppedWord = reversedWords.pop();
                System.out.print(poppedWord + " ");
            }
    }
}
