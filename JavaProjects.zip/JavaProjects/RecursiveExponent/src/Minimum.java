// Robin Johnson
// PA 8

import java.util.Arrays;

// Program that finds the minimum integer in an array
public class Minimum
{
    // Main function that creates the array and outputs the results
    public static void main(String[] args)
    {
        // create an array to be used in the program
        int[] testArray = { 15, -25, -76, 32, -10, 99, -101, 22, -77, 44 };
        // the minimum function will need the length of the array
        int length = testArray.length;

        // Find the minimum value in the array
        int minimum = recursiveMinimum(testArray, length);

        // print the results for the user to see
        System.out.println("The array contains the following integers: "
                + Arrays.toString(testArray));
        System.out.println("The smallest value in the array is: " + minimum);
    }

    // Recursive function that finds the smallest value in an int[] array
    private static int recursiveMinimum (int[] array, int length)
    {
        // ends recursion when there's only one element left to return
        if (length == 1) return array[0];
        // compares last element to the element before it
        // until the beginning of the array is reached
        else return Math.min(array[length - 1], recursiveMinimum(array, length - 1));
    }

}
