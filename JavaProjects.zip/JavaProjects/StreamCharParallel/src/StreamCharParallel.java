import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

// Class that counts how many words start with each letter in a txt file,
// using both sequential and parallel processing, so you can see the difference]
// in completion time between them
public class StreamCharParallel
{
    public static void main(String[] args) throws IOException
    {
        // Count occurrences of each character in a Stream<String>
        // using sequential processing

        // Start timer
        Instant startTime = Instant.now();

        Map<String, Long> sequentialCounts =
                Files.lines(Paths.get("./src/Chapter2Paragraph.txt"))
                    // Replaces everything that is not a word character
                    .map(line -> line.replaceAll("\\W", ""))
                    // Changes all characters to Uppercase
                    .map(String::toUpperCase)
                    // Changes map of Strings to chars
                    .flatMapToInt(String::chars)
                    .mapToObj(c -> (char) c)
                    // Counts the frequency of each character
                    // and places the characters and their counts
                    // into a TreeMap
                    .collect(Collectors.groupingBy(String::valueOf,
                            TreeMap::new, Collectors.counting()));

        // Display the characters
        sequentialCounts.entrySet()
                // Stream needed to process the key value pairs
                .stream()
                // Removes entries with empty/null values
                .filter(entry -> !entry.getKey().isEmpty())
                // Displays the character and count
                .forEach(entry -> {
                    System.out.printf("%s: %d%n", entry.getKey(), entry.getValue());
                });

        // Stop overall time
        Instant endTime = Instant.now();

        System.out.printf("\nSequential processing time: %f%n",
                Duration.between(startTime, endTime).toMillis() / 1000.0);

        // Count occurrences of each character in a Stream<String>
        // using parallel processing

        // Start timer
        startTime = Instant.now();

        Map<String, Long> parallelCounts =
                Files.lines(Paths.get("./src/Chapter2Paragraph.txt"))
                // Process the stream in parallel to take advantage of multi-core systems
                        .parallel()
                        .map(line -> line.replaceAll("\\W", ""))
                        .map(String::toUpperCase)
                        .flatMapToInt(String:: chars)
                        .mapToObj(c -> (char) c)
                        .collect(Collectors.groupingBy(String::valueOf,
                                TreeMap::new, Collectors.counting()));

        // display the letters grouped by starting letter
        parallelCounts.entrySet()
                // Process the stream in parallel to take advantage of multi-core systems
                .stream()
                .parallel()
                .filter(entry -> !entry.getKey().isEmpty())
                .forEach(entry -> {
                    System.out.printf("%s: %d%n",
                            entry.getKey(), entry.getValue());
                });

        // Stop overall time
        endTime = Instant.now();

        // *Because we used parallel processing, the starting letters will be
        //  processed and displayed out of order
        System.out.printf("\nParallel processing time: %f%n", Duration.between(startTime, endTime).toMillis() / 1000.0);
    }
}
