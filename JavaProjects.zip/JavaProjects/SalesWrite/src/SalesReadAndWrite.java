import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.IllegalFormatException;
import java.util.Scanner;

// Robin Johnson
// PA 3
public class SalesReadAndWrite
{
    public static void main(String[] args)
    {
        int numberOfSales = 0;
        double totalSales = 0.0;
        double avgSales;

        Scanner reader = new Scanner("sales.txt");
        try (Formatter writer = new Formatter("salesSummary.txt"))
        {
            // Create Sales column header
            writer.format("%s\n", "Sales");

            // Write sales amounts to file
            while (reader.hasNext())
            {
                double thisSale = reader.nextDouble();
                writer.format("%.2f\n", thisSale);
                numberOfSales++;
                totalSales += thisSale;
            }

            // Calculate average sale value
            avgSales = totalSales / numberOfSales;

            // Write summary data
            writer.format("%-15s%-15s%-15s\n", "Count", "Total Sales", "Average Sales");
            writer.format("%-15d%-15f%-15f\n", numberOfSales, totalSales, avgSales);

            System.out.println("Sale Summary has been saved.");
        }

        catch (FileNotFoundException fileNotFoundException)
        {
            System.err.println("Output file cannot be found.");
        }
        catch (IllegalFormatException illegalFormatException)
        {
            System.err.println("Error with the output's format.");
        }
        catch (FormatterClosedException formatterClosedException)
        {
            System.err.println("File has been closed.");
        }
    }
}
