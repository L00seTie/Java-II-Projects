import java.io.FileNotFoundException;
import java.util.FormatterClosedException;
import java.util.IllegalFormatException;
import java.util.Scanner;
import java.util.Formatter;

// Robin Johnson
// PA 3
public class SalesWrite
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        double salesAmount = 0.0;

        try (Formatter writer = new Formatter("sales.txt"))
        {
            // Prompt the user to enter sales amounts,
            // write those amounts to a new file
            do
            {
                System.out.println("Enter the sales amount: ");
                salesAmount = scanner.nextDouble();
                if (salesAmount != -1)
                {
                    writer.format("%.2f\n", salesAmount);
                }
            }
            while (salesAmount != -1);

            System.out.println("Sales Have Been Saved");
        }

        catch (FileNotFoundException fileNotFoundException)
        {
            System.err.println("Output file cannot be found.");
        }
        catch (IllegalFormatException illegalFormatException)
        {
            System.err.println("Error with the output's format.");
        }
        catch (FormatterClosedException formatterClosedException)
        {
            System.err.println("File has been closed.");
        }
    }
}