import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.TreeSet;
import java.util.Iterator;

// Robin Johnson
// PA 5
public class UniqueIntegers
{
    public static void main(String[] args)
    {
        // Read all values from text file
        try (FileInputStream valuesFile = new FileInputStream("values.txt"))
        {
            Scanner values = new Scanner(valuesFile);
            int totalIntegers = 0; // all integers read, including duplicates
            TreeSet<Integer> uniqueIntegers = new TreeSet<>(); // will not contain duplicates

            while (values.hasNextInt())
            {
                uniqueIntegers.add(values.nextInt()); // discards duplicates automatically
                totalIntegers++;
            }

            // Print list of unique values
            Iterator<Integer> integerList = uniqueIntegers.iterator();
            while (integerList.hasNext())
            {
                System.out.print(integerList.next() + " ");
            }
            System.out.println("\nNumber of integers: " + totalIntegers);
            System.out.println("Unique integer count: " + uniqueIntegers.size());
        }
        catch (IOException e) { throw new RuntimeException(e); }
    }
}
