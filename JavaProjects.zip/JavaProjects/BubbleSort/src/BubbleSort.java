// Robin Johnson
// PA 9

import java.util.Arrays;
import java.util.Random;
import java.util.stream.IntStream;

// Class that uses a bubble sort algorithm to sort a random
// array of integers
public class BubbleSort
{
    // Main function that creates and sorts an array
    public static void main(String[] args)
    {
        int[] testArray = new int[20];
        generateValues(testArray);

        System.out.println("Unsorted array: " + Arrays.toString(testArray));
        bubbleSort(testArray);
        System.out.println("Sorted array: " + Arrays.toString(testArray));
    }

    // Function that populates testArray with a random set of integers
    // from 1 to 200
    private static void generateValues(int[] testArray)
    {
        Random random = new Random();
        IntStream.range(0, testArray.length) // generates the indexes
                .forEach(i -> testArray[i] = random.nextInt(200) + 1);
    }

    // Function that uses a bubble sort algorithm to sort the integer array
    private static void bubbleSort(int[] array)
    {
        int length = array.length;
        int temp; // for swapping
        boolean swapped;

        // no need to iterate through the last element
        for (int i = 0; i < length - 1; i++)
        {
            swapped = false;

            // goes to length - 1 - i because the largest element
            // will become sorted each pass and can be skipped
            for (int j = 0; j < length - 1 - i; j++)
            {
                if (array[j] > array[j + 1])
                {
                    // swap them
                    temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }

            // if no elements were swapped, the array is sorted
            if (!swapped) { break; }
        }
    }
}
