import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import java.util.LinkedHashMap;
import java.util.Map;
import java.io.*;

public class JSONWrite
{
    public static void main(String[] args) throws Exception
    {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter Student Name: ");
        String name = input.nextLine();

        // Create a new JSON object
        JSONObject root = new JSONObject();
        // Put the name name-value pair
        root.put("name", name);

        System.out.print("Enter Student ID: ");
        String ID = input.nextLine();

        // Put the stydent ID name-value pair
        root.put("ID", ID);

        System.out.print("Enter Student's Program: ");
        String program = input.nextLine();

        // Put the program name-value pair
        root.put("program", program);

        // Put the level name-value pair
        System.out.print("Enter the level: ");
        String level = input.nextLine();

        // Put the level name-value pair
        root.put("level", level);

        //For address data, first create LinkedHashMap
        Map address = new LinkedHashMap(4);
        System.out.print("Enter the street address: ");
        String street = input.nextLine();
        // Put street address
        address.put("streetAddress", street);
        System.out.print("Enter the city: ");
        String city = input.nextLine();
        // Put city
        address.put("city", city);
        System.out.print("Enter the state: ");
        String state = input.nextLine();
        // Put state
        address.put("state", state);
        System.out.print("Enter the postal code: ");
        String postalCode = input.nextLine();
        // Put postal code
        address.put("postalCode", postalCode);

        // Put address to JSONObject
        root.put("address", address);


        // Create a JSON array for the courses
        JSONArray courses = new JSONArray();

        while(true) {
            // get the course name
            System.out.print("Enter course name (Press enter to end): ");
            String course = input.nextLine();
            // check to see if user hit enter
            if(course.isEmpty())
            {
                break;
            }
            // get the grade
            System.out.println("Enter grade: ");
            String grade = input.nextLine();

            // Create a JSON object and store a course object in it
            JSONObject courseObj = new JSONObject();
            courseObj.put("name", course);
            courseObj.put("grade", grade);
            // Add the course to the array
            courses.add(courseObj);
        }

        // Add the array to the root object
        root.put("courses", courses);

        // Print out JSONString
        System.out.println(root.toJSONString());

        // Create the file and write the JSON to it
        File file = new File("StudentGrades.json");
        try (PrintWriter writer = new PrintWriter(file))
        {
            writer.print(root.toJSONString());
            System.out.println("Information written to file");
        }
        catch (FileNotFoundException ex)
        {
            System.out.println(ex.toString());
        }
    }
}
