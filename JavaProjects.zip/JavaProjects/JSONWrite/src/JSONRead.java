import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.*;
import java.util.Iterator;
import java.util.Map;

public class JSONRead
{
    public static void main(String[] args) throws Exception
    {
        try (FileInputStream fileStream = new FileInputStream("StudentGrades.json"))
        {
            // Use a scanner and stringBuilder to read from the file and create a string with it
            Scanner output = new Scanner(fileStream);
            StringBuilder jsonIn = new StringBuilder();

            // Read the json file into a string builder
            while (output.hasNextLine())
            {
                jsonIn.append(output.nextLine());
            }

            // Parse the string and cast it to a JSONObject
            JSONParser parser = new JSONParser();
            JSONObject root = (JSONObject) parser.parse(jsonIn.toString());

            // Get and print root level student information
            System.out.printf("Student name is %s\n", root.get("name").toString());
            System.out.printf("Student ID is %s \n", root.get("ID").toString());
            System.out.printf("Program is %s\n", root.get("program").toString());
            System.out.printf("Level is %s\n\n", root.get("level").toString());

            System.out.println("Address Information");
            // Get the address and save it as a Map object
            Map address = ((Map)root.get("address"));
            // Iterate over the Map entries to print the key value pairs
            Iterator<Map.Entry> iterator = address.entrySet().iterator();
            while (iterator.hasNext())
            {
                Map.Entry pair = iterator.next();
                System.out.println(pair.getKey() + " : " + pair.getValue());
            }

            System.out.println("\nCourse Information");
            // Get the course information, which is stored in a JSONArray
            JSONArray courses = (JSONArray) root.get("courses");
            for (int i = 0; i < courses.size(); i++)
            {
                // Create a JSON object to hold the course information
                JSONObject course = (JSONObject) courses.get(i);
                String grade = (String) course.get("grade");
                String name = (String) course.get("name");
                System.out.printf("Course %s: grade %s\n", name, grade);
            }
        }
        catch (FileNotFoundException fileNotFoundException)
        {
            System.out.println(fileNotFoundException.toString());
        }
        catch (ParseException parseException)
        {
            System.out.println(parseException.toString());
        }
    }
}
