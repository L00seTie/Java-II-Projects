import java.util.Scanner;
// Robin Johnson
// PA 2
public class StringSearch
{
    public static void main(String[] args)
    {
        // Get text from the user
        Scanner scnr = new Scanner(System.in);
        System.out.println("Please enter text to be searched.");
        String userText = scnr.nextLine();

        // Create arrays to be used in searching and the final table
        char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        char[] upperCases = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
        int[] letterOccurrences = new int[26]; // 26 letters

        // For every letter in the alphabet, search for occurrences in userText
        for (int i = 0; i < alphabet.length; i++)
        {
            char thisLetter = alphabet[i];
            char uppercaseEquiv = upperCases[i];
            int totalOccurrences = getTotalOccurrences(userText, thisLetter, uppercaseEquiv);
            letterOccurrences[i] = totalOccurrences;
        }

        // Print results as a table
        System.out.println("Total letters in your text:");
        for (int i = 0; i < alphabet.length; i++)
        {
            System.out.println(alphabet[i] + "\t" + letterOccurrences[i]);
        }
        System.out.println("Number of characters in your text: " + userText.length());
    }

    // Find occurrences of a letter and its uppercase equivalent in a string
    private static int getTotalOccurrences(String userText, char thisLetter, char uppercaseEquiv) {
        int indexOfThisLetter = userText.indexOf(thisLetter);
        int indexOfUppercase = userText.indexOf(uppercaseEquiv);
        int totalOccurrences = 0;

        while (indexOfThisLetter != -1)
        {
            totalOccurrences++;
            indexOfThisLetter = userText.indexOf(thisLetter, indexOfThisLetter + 1);
        }
        while (indexOfUppercase != -1)
        {
            totalOccurrences++;
            indexOfUppercase = userText.indexOf(uppercaseEquiv, indexOfUppercase + 1);
        }
        return totalOccurrences;
    }
}
