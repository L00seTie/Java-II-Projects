import java.util.Scanner;
public class Index
{
     public static void main(String[] args)
     {
         // get text
         Scanner scnr = new Scanner(System.in);
         System.out.println("Please enter Text to be Searched");
         String text = scnr.nextLine();

         // get searching character
         System.out.println("Please enter a character");
         char key = scnr.next().charAt(0);

         // search for input character
         int count = 0;
         int current = text.indexOf(key, 0);

         while (current != -1)
         {
             count++;
             current = text.indexOf(key, current + 1);
         }

         // display results
         System.out.printf("Number of %s's: %d\n", key, count);
     }
}
