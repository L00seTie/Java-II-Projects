import java.util.Scanner;
// Robin Johnson
// PA 2
public class FindED
{
    public static void main(String[] args)
    {
        // Get text from the user
        Scanner scnr = new Scanner(System.in);
        System.out.println("Please enter text to be searched.");
        String userText = scnr.nextLine();

        // Split into words
        String[] words = userText.split(" ");

        // Print words ending in "ed"
        System.out.println("\nWords ending in \"ed\":");
        for (int i = 0; i < words.length; i++)
        {
            if (words[i].endsWith("ed") ||
                words[i].endsWith("ED") ||
                words[i].endsWith("Ed") ||
                words[i].endsWith("eD"))
            {
                System.out.println(words[i]);
            }
        }
    }
}
