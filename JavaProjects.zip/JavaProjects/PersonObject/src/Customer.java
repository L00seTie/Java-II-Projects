public class Customer extends Person
{
    private String customerNumber;
    private String onMailingList;

    // Constructor
    public Customer(String name, String address, String cellNumber,
                    String customerNumber, String onMailingList)
    {
        super(name, address, cellNumber);
        this.customerNumber = customerNumber;
        this.onMailingList = onMailingList;
    }

    // Accessor (getter) Methods:
    // Returns the customer number
    public String getCustomerNumber( )
    {
        return customerNumber;
    }

    // Returns on mailing list
    public String getOnMailingList( )
    {
        return onMailingList;
    }

    // Mutator (setter) Methods:
    // Sets the customer number
    public void setCustomerNumber(String customerNumber)
    {
        this.customerNumber =  customerNumber;
    }

    // Sets on Mailing list
    public void setOnMailingList(String onMailingList)
    {
        this.onMailingList = onMailingList;
    }

    // Returns the Customer information
    @Override
    public String toString( )
    {
        return super.toString() + "\nCustomer Number: " + customerNumber
                                + "\nOn Mailing List: " + onMailingList;
    }
}
