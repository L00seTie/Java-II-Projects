public class PersonCustomerTester
{
    public static void main(String[] args)
    {
        // Create and display a Person instance/object
        Person personOne = new Person("Marla Owens", "111 10th Ave W", "701-555-1234");
        System.out.println("Person information:");
        System.out.println(personOne.toString());

        // Update the person instance/object
        personOne.setName("Chuck Owens");
        personOne.setAddress("4790 Leopard Circle");
        personOne.setCellNumber("480-282-4321");

        // Display the Person instance/object
        System.out.println("\nUpdated Person Information:");
        System.out.println("Name: " + personOne.getName()
                            + "\nAddress: " + personOne.getAddress()
                            + "\nCell Number: " + personOne.getCellNumber());

        // Create and display a Customer instance/object
        Customer customerOne = new Customer("Pam Winters", "501 Customer St.", "701-225-9620", "PW1234", "Yes");
        System.out.println("\nCustomer Information:");
        System.out.println(customerOne.toString());

        // Update the customer instance/object
        customerOne.setName("Steve Walker");
        customerOne.setAddress("1234 Main St");
        customerOne.setCellNumber("212-555-3674");
        customerOne.setCustomerNumber("SW9876");
        customerOne.setOnMailingList("No");

        // Display the Customer instance/object
        System.out.println("\nUpdated Customer Information:");
        System.out.println("Name: " + customerOne.getName()
                            + "\nAddress: " + customerOne.getAddress()
                            + "\nCell Number: " + customerOne.getCellNumber()
                            + "\nCustomer Number: " + customerOne.getCustomerNumber()
                            + "\nOn Mailing List: " + customerOne.getOnMailingList());
    }
}
