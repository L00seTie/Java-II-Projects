//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main
{
    public static void main(String[] args)
    {
        for (int i = 0; i < 10; i++)
        {
            System.out.println("We're on iteration " + i + ".");
            if (i == 5)
            {
                System.out.println("Halfway there!");
            }
        }
        System.out.println("We've finished the loop");
    }
}