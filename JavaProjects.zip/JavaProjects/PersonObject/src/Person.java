// Person class that includes a name, address, and cell number
public class Person
{
    private String name;
    private String address;
    private String cellNumber;

    // Constructor
    public Person(String name, String address, String cellNumber)
    {
        this.name = name;
        this.address = address;
        this.cellNumber = cellNumber;
    }

    // Accessor (getter) Methods:
    // Returns the name
    public String getName( )
    {
        return name;
    }

    // Returns the address
    public String getAddress( )
    {
        return address;
    }

    // Returns the cell number
    public String getCellNumber( )
    {
        return cellNumber;
    }

    // Mutator (setter) Methods:
    // Sets the name
    public void setName(String name)
    {
        this.name = name;
    }

    // Sets the address
    public void setAddress(String address)
    {
        this.address = address;
    }

    // Sets the cell number
    public void setCellNumber(String cellNumber)
    {
        this.cellNumber = cellNumber;
    }

    @Override
    // Returns the Person information
    public String toString( )
    {
        return "Name: " + name
                + "\nAddress: " + address
                + "\nCell Number: " + cellNumber;
    }
}
