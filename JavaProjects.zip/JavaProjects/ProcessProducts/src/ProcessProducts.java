// Robin Johnson
// PA 7

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

// Takes an array of Product objects and queries it
public class ProcessProducts
{
    public static void main(String[] args)
    {
        // Create the products table
        Product[] products = {
                new Product("B005OCFHHK", "Harry Potter: 8-Film Collection", "Movies and TV", 39.99, 45),
                new Product("B07XJ8C8F5", "Echo Dot Smart Speaker", "Electronics", 29.99, 30),
                new Product("B08G3MN6KP", "Super Mario 3D All Stars", "Video Games", 49.94, 12),
                new Product("B07JCRY8WP", "Minecraft", "Video Games", 29.88, 10),
                new Product("B082JP6VP5", "John Wick: Chapters 1-3", "Movies and TV", 22.29, 18),
                new Product("B07FKR6KXF", "Fire 7 Tablet", "Electronics", 49.99, 15),
                new Product("B075XLWML4", "Roku Streaming Stick", "Electronics", 47.92, 5),
                new Product("B07DJWBYKP", "Cyberpunk 2077", "Video Games", 34.99, 35)
        };

        // Convert the table to a List so that it can be used with a Stream
        List<Product> productList = Arrays.asList(products);

        // Sort table entries by price, display results.
        System.out.println("(a) Products sorted by price:");
        productList.stream()
                .sorted(Comparator.comparing(Product::getPrice)) //orders entries by price
                .forEach(product -> System.out.printf("%-13s %-35s %-15s %-8.2f %-14d %n",
                        product.getProdNumber(), product.getProdName(), product.getDepartment(),
                        product.getPrice(), product.getQuantity())); //prints entries as a table
        System.out.println(); //whitespace

        // Sort table entries by department, display results.
        System.out.println("(b) Products sorted by department:");
        productList.stream()
                .sorted(Comparator.comparing(Product::getDepartment)) //orders entries by department
                .forEach(product -> System.out.printf("%-13s %-35s %-15s %-8.2f %-14d %n",
                        product.getProdNumber(), product.getProdName(), product.getDepartment(),
                        product.getPrice(), product.getQuantity())); //prints entries as a table
        System.out.println(); //whitespace

        // Sort table entries by quantity, display results.
        System.out.println("(c) Products mapped to product name, department and quantity:");
        productList.stream()
                .sorted(Comparator.comparing(Product::getQuantity)) //orders entries by quantity
                .map(product -> String.format("%-35s %-15s %-14d",
                        product.getProdName(), product.getDepartment(), product.getQuantity()))
                .forEach(System.out::println); //prints entries as a table
        System.out.println(); //whitespace

        // Display entries where price > $30 and quantity < 30, order by price.
        System.out.println("(d) Products mapped to product name, price and quantity " +
                "where price > $30 and quantity < 30:");
        productList.stream()
                .filter(product -> product.getPrice() > 30.00) //finds products that cost more than $30
                .filter(product -> product.getQuantity() < 30) //of those, finds ones that have < 30 in stock
                .sorted(Comparator.comparing(Product::getPrice)) //orders them by price
                .map(product -> String.format("%-35s %-8.2f %-14d",
                        product.getProdName(), product.getPrice(), product.getQuantity()))
                .forEach(System.out::println); //prints entries as a table
        System.out.println(); //whitespace

        // Find and display the first entry whose department contains the word "Games".
        System.out.println("(e) Display first product where the department contains the word \"Games\":");
        productList.stream()
                .filter(product -> product.getDepartment().contains("Games")) //works with the next line
                .findFirst() //returns only the first product with "Games" in the department name
                .ifPresentOrElse( // findFirst() can return a null value if nothing matches the criteria
                        product -> System.out.println("Result: " + product), //output if not null
                        () -> System.out.println("No product found in the Games department.")); //output if null

    }

}
