// Robin Johnson
// PA 6
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

// Program that creates, updates, and displays the roster for a soccer team
public class MapDemo
{
    public static void main(String[] args)
    {
        // Make a HashMap containing jersey #s and corresponding names
        HashMap<Integer, String> teamRoster = new HashMap<>();
        teamRoster.put(5, "Alice Rogers");
        teamRoster.put(14, "Juan Gomez");
        teamRoster.put(32, "Peter Piper");
        teamRoster.put(18, "Penelope Cruz");
        teamRoster.put(9, "John Peters");

        // Display the number of players if teamRoster is not empty
        if (!teamRoster.isEmpty())
        {
            System.out.println("The roster contains " + teamRoster.size() + " players\n");
        }

        // Display the roster
        printRoster(teamRoster);

        // Remove Penelope from the roster
        teamRoster.remove(18);

        // Add two players to the roster
        teamRoster.put(8, "Miguel Diaz");
        teamRoster.put(17, "Isabella Bautista");

        // Change Alice's last name
        teamRoster.put(5, "Alice Rogers-Jones");

        // Display updated roster
        printRoster(teamRoster);

        // Search for jersey number 14 and 18
        // if found, display player's name, if not, display
        // "player not found"
        if (teamRoster.get(14) == null)
        {
            System.out.println("A player with that number is not on the roster");
        }
        else
        {
            System.out.println(teamRoster.get(14) + " roster number is 14");
        }
        if (teamRoster.get(18) == null)
        {
            System.out.println("A player with that number is not on the roster");
        }
        else
        {
            System.out.println(teamRoster.get(18) + " roster number is 18");
        }
        System.out.println(); // For formatting

        // Sort the roster by jerseyNumber
        TreeMap<Integer, String> sortedRoster = new TreeMap<>(teamRoster);

        // Display sorted roster
        printRoster(sortedRoster);

    }

    // Function that prints all team members and jersey #s (takes any Map)
    private static void printRoster(Map<Integer, String> roster)
    {
        System.out.println("Current roster");
        //
        for (Map.Entry<Integer, String> player: roster.entrySet())
        {
            System.out.println(player.getKey() + "\t\t" + player.getValue());
        }
        System.out.println(); // For formatting
    }

}
