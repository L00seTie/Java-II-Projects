// Robin Johnson
// PA 3

import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.IllegalFormatException;
import java.util.Scanner;

// Takes a list of sale prices from the user
// and writes them to a text file called sales.txt
public class SalesWrite
{
    public static void main(String[] args)
    {
        /* Creates a Formatter to write to the "sales.txt" file,
        *  which will be created automatically
        *  if it doesn't already exist */
        try (Formatter salesFile = new Formatter("sales.txt"))
        {
            // Gets sales amounts from user, ends if user enters -1
            Scanner salesAmounts = new Scanner(System.in);
            double thisSale;
            do
            {
                // Prompts the user for an amount
                System.out.println("Enter the sales amount: ");
                thisSale = salesAmounts.nextDouble();

                // Writes the amount to sales.txt, rounds to two decimals
                if (thisSale != -1)
                { salesFile.format("%.2f\n", thisSale); }
            }
            while (thisSale != -1);

            System.out.println("Sales Have Been Saved");
        }
        // 
        catch (FileNotFoundException fileNotFoundException)
        {
            System.err.println("Output file cannot be found.");
        }
        catch (IllegalFormatException illegalFormatException)
        {
            System.err.println("Error with the output's format.");
        }
        catch (FormatterClosedException formatterClosedException)
        {
            System.err.println("File has been closed.");
        }

    }
}
