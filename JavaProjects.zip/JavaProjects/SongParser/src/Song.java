// Robin Johnson
// PA 3

// Song.java
// Song class that stores the artist, song name, album name, genre, song length, song price and if the lyrics are explicit
public class Song {
   private String artist;
   private String songName;
   private String albumName;
   private String genre;
   private int duration; // in milliseconds
   private double songPrice;
   private boolean isExplicit;


   // constructor
   public Song(String artist, String songName, String albumName, String genre, int duration, double songPrice, boolean isExplicit) {

      this.artist = artist;
      this.songName = songName;
      this.albumName = albumName;
      this.genre = genre;
      this.duration = duration;
      this.songPrice = songPrice;
      this.isExplicit = isExplicit;
   }

   // get artist
   public String getArtist() {
      return artist;
   }

   // get song name
   public String getSongName() {
      return songName;
   }

   // get album name
   public String getAlbumName() {
      return albumName;
   }

   // get genre
   public String getGenre() {
      return genre;
   }

   // get song duration  
   public String getDuration() {
      int minutes = duration / 60000;
      int seconds = (duration % 60000) / 1000; // find remaining seconds
      String formattedSeconds = (seconds < 10) ? "0" + seconds : String.valueOf(seconds);
      return minutes + ":" + formattedSeconds;
   }

   // get song price
   public double getSongPrice() {
      return songPrice;
   }

   // get is explicit
   public String isExplicit() {
      if (isExplicit) { return "Yes"; }
      else { return "No"; }
   }

   // Set artist
   public void setArtist(String artist) {
      this.artist = artist;
   }

   // Set song name
   public void setSongName(String songName) {
      this.songName = songName;
   }

   // Set album name
   public void setAlbumName(String albumName) {
      this.albumName = albumName;
   }

   // set genre
   public void setGenre(String genre) {
      this.genre = genre;
   }

   // set duration
   public void setDuration(int duration) {
      this.duration = duration;
   }

   // set is explicit
   public void setIsExplicit(boolean isExplicit) {
      this.isExplicit = isExplicit;
   }


   // return String representation of Song object
   @Override
   public String toString() {
      return "Artist: " + artist + "\n" +
              "Song: " + songName + "\n" +
              "Album: " + albumName + "\n" +
              "Genre: " + genre + "\n" +
              "Duration: " + getDuration() + "\n" +
              "Song Price: $" + songPrice + "\n" +
              "Is Explicit: " + isExplicit();
   }
}
