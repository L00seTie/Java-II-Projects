// Robin Johnson
// PA 3

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// SongParser.java
// Class that prints information about a song using a .json file
public class SongParser
{
    public static void main(String[] args)
    {
        // Get a file directory from the user
        Scanner userText = new Scanner(System.in);
        System.out.println("Please enter the path and name of the json file:");
        String filePath = userText.nextLine();

        // Save the contents of that file as a String
        try (FileInputStream fileStream = new FileInputStream(filePath))
        {
            Scanner songFile = new Scanner(fileStream);
            StringBuilder jsonString = new StringBuilder();
            while (songFile.hasNextLine())
            {
                jsonString.append(songFile.nextLine());
            }

            // Parse that String for JSON and cast it as a JSONObject
            JSONParser parser = new JSONParser();
            JSONObject root = (JSONObject) parser.parse(jsonString.toString());

            // Create a new Song instance using the values from the JSONObject
            String artist = root.get("artistName").toString();
            String songName = root.get("trackName").toString();
            String albumName = root.get("collectionName").toString();
            String genre = root.get("primaryGenreName").toString();

            /* The song duration is interpreted as a Long;
            * I'm converting it to an int here so that
            * it can be passed as an argument to the Song constructor */
            long trackTimeMillis = (Long) root.get("trackTimeMillis");
            int duration = (int) trackTimeMillis;

            double songPrice = (double) root.get("trackPrice");
            boolean isExplicit = root.get("trackExplicitness").toString().equals("explicit");
            Song song = new Song(artist, songName, albumName, genre, duration, songPrice, isExplicit);

            // return information from the song object
            System.out.print(song.toString());
        }

        catch (FileNotFoundException fileNotFoundException)
        {
            System.out.println("File not found: " + fileNotFoundException);
        }
        catch (ParseException parseException)
        {
            System.out.println("Parser issue: " + parseException);
        }
        catch (ClassCastException classCastException)
        {
            System.out.println("Casting issue: " + classCastException);
        }
        catch (NullPointerException nullPointerException)
        {
            System.out.println("No value for duration/price: " + nullPointerException);
        }
        catch (IOException ioException)
        {
            throw new RuntimeException(ioException);
        }

    }
}
