// Robin Johnson
// 4/1/2024
import java.util.Scanner;

// Calculates and prints the factorial of a number entered by the user
public class FactorialCalculator
{
    public static void main(String[] args)
    {
        // Take a number from the user
        Scanner userNumber = new Scanner(System.in);
        System.out.println("Enter a number:");
        int n = userNumber.nextInt(); //!Could add validation

        // Calculate the factorial
        long solution = calcFactorial(n);

        // Output that to the user
        System.out.println("Factorial of " + n + ": " + solution);
    }

    // Uses a recursive function to calculate the factorial
    private static long calcFactorial(int n)
    {
        long solution;
        if (n == 0) {solution = 1;}
        else
        { solution = n * calcFactorial(n - 1); }
        return solution;
    }
}
