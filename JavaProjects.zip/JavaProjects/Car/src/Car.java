/*
* Robin Johnson
* PA1
*/
public class Car
{
    // Properties
    private String make;
    private String model;
    private int year;

    // Constructor
    public Car(String make, String model, int year)
    {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    // Accessor Methods
    public String getMake() { return make; }
    public String getModel() { return model; }
    public int getYear() { return year;  }

    // Mutator Methods
    public void setMake(String make) { this.make = make; }

    public void setModel(String model) { this.model = model; }
    public void setYear(int year) { this.year = year; }

    // ToString Method
    @Override
    public String toString()
    {
        return "  Make: " + make +
                "\n  Model: " + model +
                "\n  Model Year: " + year;
    }
}
