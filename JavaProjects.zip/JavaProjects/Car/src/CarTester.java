/*
* Robin Johnson
* PA1
*/
import java.util.Scanner;

public class CarTester
{
    public static void main(String[] args)
    {
        Car userCar;
        String make;
        String model;
        int year;
        String userCarInfo;

        ElectricCar userElectricCar;
        int batterySize;
        int milesPerCharge;
        String userECarInfo;

        // Get car information from user
        System.out.println("Enter Car Information");
        Scanner scanner = new Scanner(System.in);
        System.out.print("  Enter the Make: ");
        make = scanner.nextLine();
        System.out.print("  Enter the Model: ");
        model = scanner.nextLine();
        System.out.print("  Enter the Model Year: ");
        year = scanner.nextInt();
        scanner.nextLine();

        userCar = new Car(make, model, year);

        // Display car information with toString method
        System.out.println("\nCar Info");
        userCarInfo = userCar.toString();
        System.out.println(userCarInfo);

        // Update car information with set methods
        System.out.println("\nEnter Updated Car Information");
        System.out.print("  Enter the Make: ");
        userCar.setMake(scanner.nextLine());
        System.out.print("  Enter the Model: ");
        userCar.setModel(scanner.nextLine());
        System.out.print("  Enter the Model Year: ");
        userCar.setYear(scanner.nextInt());
        scanner.nextLine();

        // Display updated car information with get methods
        System.out.println("\nUpdated Car Information using get methods");
        System.out.println("  Make: " + userCar.getMake() +
                            "\n  Model: " + userCar.getModel() +
                            "\n  Year: " + userCar.getYear());

        // Get electric car information from user
        System.out.println("\nEnter Electric Car Information");
        System.out.print("  Enter the Make: ");
        make = scanner.nextLine();
        System.out.print("  Enter the Model: ");
        model = scanner.nextLine();
        System.out.print("  Enter the Model Year: ");
        year = scanner.nextInt();
        System.out.print("  Enter the Battery Size: ");
        batterySize = scanner.nextInt();
        System.out.print("  Enter the Miles Per Charge: ");
        milesPerCharge = scanner.nextInt();
        scanner.nextLine();

        userElectricCar = new ElectricCar(make, model, year, batterySize, milesPerCharge);

        // Display electric car information with toString method
        System.out.println("\nElectric Car Info");
        userECarInfo = userElectricCar.toString();
        System.out.println(userECarInfo);

        // Update electric car information with set methods
        System.out.println("\nEnter Updated Electric Car Information");
        System.out.print("  Enter the Make: ");
        userElectricCar.setMake(scanner.nextLine());
        System.out.print("  Enter the Model: ");
        userElectricCar.setModel(scanner.nextLine());
        System.out.print("  Enter the Model Year: ");
        userElectricCar.setYear(scanner.nextInt());
        System.out.print("  Enter the Battery Size: ");
        userElectricCar.setBatterySize(scanner.nextInt());
        System.out.print("  Enter the Miles Per Charge: ");
        userElectricCar.setMilesPerCharge(scanner.nextInt());
        scanner.nextLine();


        // Display updated electric car information with get methods
        System.out.println("\nUpdated Electric Car Inforation using get methods");
        System.out.println("Make: " + userElectricCar.getMake() +
                "\nModel: " + userElectricCar.getModel() +
                "\nYear: " + userElectricCar.getYear() +
                "\nBattery Size: " + userElectricCar.getBatterySize() +
                "\nMiles Per Charge: " + userElectricCar.getMilesPerCharge());
    }
}