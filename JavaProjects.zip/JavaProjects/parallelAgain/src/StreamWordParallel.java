// Robin Johnson
// PA 11
/*
* Results I got when running this program:
*
* Sequential processing:
* Overall: 3.703000
* Map: 3.683000
* Display: 0.020000
*
* Parallel processing:
* Overall: 0.771000
* Map: 0.764000
* Display: 0.007000
*/

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.Map;
import java.util.TreeMap;

// Class that counts instances of each word in a text file
// using sequential and parallel processing, to demonstrate
// the difference in performance between each
public class StreamWordParallel
{
    public static void main(String[] args) throws IOException
    {
        // Regex that matches one or more consecutive whitespace characters
        Pattern pattern = Pattern.compile("\\s+");
        // Timer variables
        Instant overallStart;
        Instant overallEnd;
        Instant mappingStart;
        Instant mappingEnd;
        Instant displayStart;
        Instant displayEnd;

        /* Count occurrences of each word using sequential processing */

        // Start overall timer
        overallStart = Instant.now();

        // Start mapping timer
        mappingStart = Instant.now();
        // Count occurrences of each word in a Stream<String> sorted by word
        Map<String, Long> wordCounts = Files.lines(Paths.get("Chapter2Paragraph.txt"))
                .flatMap(pattern::splitAsStream)
                .collect(Collectors.groupingBy(String::toLowerCase,
                        TreeMap::new, Collectors.counting()));
        // End mapping timer
        mappingEnd = Instant.now();

        // Start displaying timer
        displayStart = Instant.now();
        // Display the words grouped by starting letter
        wordCounts.entrySet()
                .stream()
                .collect(Collectors.groupingBy(entry -> entry.getKey().charAt(0),
                        TreeMap::new, Collectors.toList()))
                .forEach((letter, wordList) -> {
                    System.out.printf("%n%C%n", letter);
                    wordList.stream().forEach(word -> System.out.printf("%13s: %d%n",
                            word.getKey(), word.getValue()));
                });
        // Stop displaying timer
        displayEnd = Instant.now();

        // Stop overall time
        overallEnd = Instant.now();

        // Print all timer results
        System.out.printf("\nOverall sequential processing time: %f%n",
                Duration.between(overallStart, overallEnd).toMillis() / 1000.0);
        System.out.printf("Map sequential processing time: %f%n",
                Duration.between(mappingStart, mappingEnd).toMillis() / 1000.0);
        System.out.printf("Display sequential processing time: %f%n",
                Duration.between(displayStart, displayEnd).toMillis() / 1000.0);


        /* Count occurrences of each word using parallel processing */

        // Start timer
        overallStart = Instant.now();

        /// Start overall timer
        overallStart = Instant.now();

        // Start mapping timer
        mappingStart = Instant.now();
        // Count occurrences of each word in a Stream<String> sorted by word
        wordCounts = Files.lines(Paths.get("Chapter2Paragraph.txt"))
                .flatMap(pattern::splitAsStream)
                .parallel()
                .collect(Collectors.groupingBy(String::toLowerCase,
                        TreeMap::new, Collectors.counting()));
        // End mapping timer
        mappingEnd = Instant.now();

        // Start displaying timer
        displayStart = Instant.now();
        // Display the words grouped by starting letter
        wordCounts.entrySet()
                .stream()
                .parallel()
                .collect(Collectors.groupingBy(entry -> entry.getKey().charAt(0),
                        TreeMap::new, Collectors.toList()))
                .forEach((letter, wordList) -> {
                    System.out.printf("%n%C%n", letter);
                    wordList.stream().forEach(word -> System.out.printf("%13s: %d%n",
                            word.getKey(), word.getValue()));
                });
        // Stop displaying timer
        displayEnd = Instant.now();

        // Stop overall time
        overallEnd = Instant.now();

        // Print all timer results
        System.out.printf("\nOverall sequential processing time: %f%n",
                Duration.between(overallStart, overallEnd).toMillis() / 1000.0);
        System.out.printf("Map sequential processing time: %f%n",
                Duration.between(mappingStart, mappingEnd).toMillis() / 1000.0);
        System.out.printf("Display sequential processing time: %f%n",
                Duration.between(displayStart, displayEnd).toMillis() / 1000.0);
    }
}
