import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class DieRollOutput
{
    public static void main(String[] args)
    {
        int[] rollsPerSide = new int[7];

        Formatter writer = null;
        Scanner rollScanner = null;

        try
        {
            // Open the dieRolls file
            rollScanner = new Scanner(new File("dieRolls.txt"));
            // Create new file to write results to
            writer = new Formatter("output.txt");

            // Write the header row for the output file
            writer.format("%-12s%-12s\n", "Die", "Count");

            // Count rolls corresponding to indices in the array
            while (rollScanner.hasNext())
            {
                rollsPerSide[rollScanner.nextInt()]++;
            }

            // Write results to file
            for (int side = 1; side < rollsPerSide.length; side++)
            {
                writer.format("%-12s%-12s\n", side, rollsPerSide[side]);
            }

            System.out.println("Die roll totals have been saved.");
        }

        catch (FileNotFoundException fileNotFoundException)
        {
            System.err.println("Error: files cannot be opened");
        }
        catch (FormatterClosedException formatterClosedException)
        {
            System.err.println("Error: Output file is closed.");
        }
        catch (SecurityException securityException)
        {
            System.err.println("Error opening file for writing.");
        }
        catch (IllegalFormatException illegalFormatException)
        {
            System.err.println("Error writing data to file.");
        }
        catch (NoSuchElementException noSuchElementException)
        {
            System.err.println("Error reading from file.");
        }
        catch (IllegalStateException illegalStateException)
        {
            System.err.println("Error: Input file is closed.");
        }
        finally
        {
            if (writer != null) { writer.close(); }
            if (rollScanner != null) { rollScanner.close(); }
        }
    }
}
