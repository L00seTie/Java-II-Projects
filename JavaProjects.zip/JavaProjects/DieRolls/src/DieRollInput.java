import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.IllegalFormatException;
import java.util.NoSuchElementException;
import java.security.SecureRandom;

public class DieRollInput
{
    private static final int NUMBER_OF_ROLLS = 10000;

    public static void main(String[] args)
    {
        SecureRandom randomNumbers = new SecureRandom();

        //Create output stream
        // note: if you don't specify where your file is to be saved, it
        // will default to your current working directory
        try (Formatter dieRolls = new Formatter("dieRolls.txt"))
        {
            int dieRoll;

            for (int i = 0; i < NUMBER_OF_ROLLS; i++)
            {
                dieRoll = randomNumbers.nextInt(6) + 1;
                dieRolls.format("%d\n", dieRoll);
            }

            System.out.println("Die rolls have been saved.");
        }

        //Error handling
        catch (SecurityException securityException)
        {
            System.err.println("Error opening file.");
        }
        catch (FileNotFoundException fileNotFoundException)
        {
            System.err.println("Output file cannot be found.");
        }
        catch (IllegalFormatException illegalFormatException)
        {
            System.err.println("Error with the output's format.");
        }
        catch (FormatterClosedException formatterClosedException)
        {
            System.err.println("File has been closed.");
        }

    }
}
